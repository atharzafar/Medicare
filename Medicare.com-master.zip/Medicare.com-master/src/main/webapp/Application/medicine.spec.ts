import { Medicine } from './medicine';

describe('Medicine', () => {
  it('should create an instance', () => {
    expect(new Medicine()).toBeTruthy();
  });
});
